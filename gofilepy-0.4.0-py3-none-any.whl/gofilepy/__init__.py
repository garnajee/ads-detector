from .gofile import (
    gofile_upload,
    upload,
    opts,
    main
)

# (optionnal)
__version__ = "0.4.0"

# public exports
__all__ = [
    'gofile_upload',
    'upload',
    'opts', 
    'main'
]
